install java latest version
install netbeans 
install mysql server or phpmyadmin
import project in netbeans
import examshow.sql in sql server

database setup
goto examshow/src/java/connection and change these parameter

String url = "jdbc:mysql://localhost:3306/examshow";  //examshow ==> database name
String user = "root";  //datbase username

String pass = "root"; //datbase password
