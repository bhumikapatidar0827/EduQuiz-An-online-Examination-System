/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mail;


import javax.mail.*;
import javax.mail.internet.*;
import java.util.*;
public class MailVerify {

    String code;
    String d_email = "bhumikapatidar0827@gmail.com",
d_password = "jdwm xetk qdzq grbn",
d_host = "smtp.gmail.com",
d_port = "465",
m_subject = "Verification Process",
m_to,
m_text ;

public MailVerify(String email, String m1_text)
{
    m_to = email;
   m_text = m1_text;
} 

 public void verify()
{
Properties props = new Properties();

props.put("mail.smtp.host", "smtp.gmail.com");
props.put("mail.smtp.port", "465");
props.put("mail.smtp.ssl.enable","true");
props.put("mail.smtp.auth", "true");
props.put("mail.smtp.debug", "true");
props.put("mail.smtp.socketFactory.port", d_port);
props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
props.put("mail.smtp.socketFactory.fallback", "false");

try
{
Session session = Session.getInstance(props, new Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication("bhumikapatidar0827@gmail.com", "jdwm xetk qdzq grbn");
			}
		});

session.setDebug(true);
MimeMessage msg = new MimeMessage(session);
msg.setText(m_text);
msg.setSubject(m_subject);
msg.setFrom(new InternetAddress(d_email));
msg.addRecipient(Message.RecipientType.TO, new InternetAddress(m_to));
Transport.send(msg);
}
catch (Exception mex)
{
mex.printStackTrace();
}
}

public static void main(String args[])
{
    /*
SendMail blah = new SendMail();
blah.sms2();
* */
}

}

    

